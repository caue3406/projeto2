import { Injectable } from '@angular/core';
import { SocialAuthService, GoogleLoginProvider } from '@abacritt/angularx-social-login';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private isAuthenticated = false;

  constructor(private authService: SocialAuthService, private router: Router) {}

  // Método para fazer login com Google
  loginWithGoogle(): void {
    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).then((user: any) => {
      // Aqui você pode armazenar os dados do usuário
      this.isAuthenticated = true;
      this.router.navigate(['/lista-compras']); // Redireciona para a página da lista de compras
    }).catch((error: any) => {
      console.error(error);
    });
  }

  // Método para fazer logout
  logout(): void {
    this.authService.signOut().then(() => {
      this.isAuthenticated = false;
      this.router.navigate(['/login']); // Redireciona para a página de login
    });
  }

  // Método para verificar se o usuário está autenticado
  isUserAuthenticated(): boolean {
    return this.isAuthenticated;
  }
}
