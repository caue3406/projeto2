import { GoogleLoginProvider } from '@abacritt/angularx-social-login';

export const socialAuthConfig = {
  providers: [
    {
      id: GoogleLoginProvider.PROVIDER_ID,
      provider: new GoogleLoginProvider('SUA_CLIENT_ID_DO_GOOGLE'), // Substitua pelo seu Client ID
    },
  ],
};
