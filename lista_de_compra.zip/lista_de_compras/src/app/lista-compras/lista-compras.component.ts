import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Item } from '../item.model';

@Component({
  selector: 'app-lista-compras',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './lista-compras.component.html',
  styleUrls: ['./lista-compras.component.css']
})
export class ListaComprasComponent {
  novoItemNome: string = '';
  itens: Item[] = [];
  idCounter: number = 0;

  adicionarItem() {
    if (this.novoItemNome.trim()) {
      this.itens.push({
        id: this.idCounter++,
        nome: this.novoItemNome,
        comprado: false
      });
      this.novoItemNome = '';
    }
  }

  editarItem(item: Item) {
    const novoNome = prompt('Editar item', item.nome);
    if (novoNome) {
      item.nome = novoNome;
    }
  }

  marcarComoComprado(item: Item) {
    item.comprado = true;
  }

  excluirItem(item: Item) {
    this.itens = this.itens.filter(i => i.id !== item.id);
  }

  itensNaoComprados() {
    return this.itens.filter(item => !item.comprado);
  }

  itensComprados() {
    return this.itens.filter(item => item.comprado);
  }
}

