import { Component } from '@angular/core';

@Component({
  selector: 'app-tarefas',
  standalone: true,
  imports: [],
  templateUrl: './tarefas.component.html',
  styleUrl: './tarefas.component.css'
})
export class TarefasComponent {

}
